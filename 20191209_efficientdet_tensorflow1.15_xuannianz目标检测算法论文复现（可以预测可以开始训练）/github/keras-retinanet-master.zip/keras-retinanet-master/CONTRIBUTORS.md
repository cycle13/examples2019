# Contributors

This is a list of people who contributed patches to keras-retinanet.

If you feel you should be listed here or if you have any other questions/comments on your listing here,
please create an issue or pull request at https://github.com/fizyr/keras-retinanet/

* Hans Gaiser <h.gaiser@fizyr.com>
* Maarten de Vries <maarten@de-vri.es>
* Valerio Carpani
* Ashley Williamson
* Yann Henon
* Valeriu Lacatusu
* András Vidosits
* Cristian Gratie
* jjiunlin
* Sorin Panduru
* Rodrigo Meira de Andrade
* Enrico Liscio <e.liscio@fizyr.com>
* Mihai Morariu
* pedroconceicao
* jjiun
* Wudi Fang
* Mike Clark
* hannesedvartsen
* Max Van Sande
* Pierre Dérian
* ori
* mxvs
* mwilder
* Muhammed Kocabas
* Koen Vijverberg
* iver56
* hnsywangxin
* Guillaume Erhard
* Eduardo Ramos
* DiegoAgher
* Alexander Pacha
* Agastya Kalra
* Jiri BOROVEC
* ntsagko
* charlie / tianqi
* jsemric
* Martin Zlocha
* Raghav Bhardwaj
* bw4sz
* Morten Back Nielsen
* dshahrokhian
* Alex / adreo00
* simone.merello
* Matt Wilder
* Jinwoo Baek
* Etienne Meunier
* Denis Dowling
* cclauss
* Andrew Grigorev
* ZFTurbo
* UgoLouche
* Richard Higgins
* Rajat /  rajat.goel
* philipp.marquardt
* peacherwu
* Paul / pauldesigaud
* Martin Genet
* Leo / leonardvandriel
* Laurens Hagendoorn
* Julius / juliussimonelli
* HolyGuacamole
* Fausto Morales
* borakrc
* Ben Weinstein
* Anil Karaka
* Andrea Panizza
