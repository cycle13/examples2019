# -*- coding: UTF-8 -*-
"""
Model fusion
fun:
    预测降雨量
    模型融合 xgb + 随即森林 + GRU
env:
	supermapBJAIGPU 103.254.67.181:10006
	Ubuntu 16.04.5 LTS,Linux version 4.15.0-43-generic;container root@9c0aee92cfa5
	pycharm;python 2.7;pip2 list;numpy1.16.1;pandas0.24.1;matplotlib2.2.3;
	tensorflow-gpu1.12.0;Keras2.2.4
	scikit-learn0.20.3;xgboost0.82;
"""
import os.path
os.environ["CUDA_VISIBLE_DEVICES"] = "1,0"#elesun use supermapBJGPU

import sys
sys.path.append('..') #elesun
import rfmodel as rf
import pandas as pd
import numpy as np
from dataprocess import FeatureSelect as fs
from dataprocess import data_process8 as dp
from dataprocess import generate_percentile as gp
import xgbmodel as xgbm
import bigrumodel as bigru


def check_code(mode, gru_mode):

    if(mode == 'simple'):
        train_df = pd.read_csv('../data/train_percentile.csv')
        test_df = pd.read_csv('../data/testB_percentile.csv')
        train_add = pd.read_csv('../data/train_old_wind_4240.csv')
        testA_add = pd.read_csv('../data/testB_old_wind_4240.csv')
        train_1ave8extend = pd.read_csv('../data/train_new_wind_1ave_8extend.csv')
        test_1ave = pd.read_csv('../data/testB_new_wind_1ave_8extend.csv')
    else:
        trainfile = '../data/train.txt'
        testBfile = '../data/testB.txt'
        #生成训练集数据,老的风
        train_add = dp.dataprocess(trainfile, data_type='train', windversion='old')
        #生成测试集B数据,老的风
        testA_add = dp.dataprocess(testBfile, data_type='testB', windversion='old')
        #生成训练集数据,1ave8extend
        train_1ave8extend = dp.dataprocess(trainfile, data_type='train', windversion='new')
        #生成测试集B数据,1ave
        test_1ave = dp.dataprocess(testBfile, data_type='testB', windversion='new')
        #生成训练集数据
        train_df = gp.data_process(trainfile, data_type='train')
        #生成测试集B数据
        test_df = gp.data_process(testBfile, data_type='testB')
    print('#data process has been done')

    result_xgb = xgbm.xgbmodeltrain(train_1ave8extend, test_1ave)
    print('#xgb model has been done')

    index = fs.pre_train(train_df=train_df, test_df=test_df, train_add=train_add, test_add=testA_add)
    valid = rf.rf_model(train_df, test_df, 'train', train_add, testA_add, ne=100)
    ne = 100#elesun 1100
    result_rf = rf.rf_model(train_df, test_df, 'trai', train_add, testA_add, ne, index=index)
    print('#rf model has been done')

    result_bigru = bigru.BiGRU_train(train_df, test_df, valid, gru_mode).reshape(2000)
    print('#bigru model has been done')

    ensemble = (result_xgb+result_rf+result_bigru)/3.0
    np.savetxt("./submit.csv", ensemble)

#check_code('all','online')#elesun first dataprocess then train
#check_code('simple', 'online')#elesun second open data then train
check_code('simple', 'pretrained')#elesun third open data then train using pretrained gru model


