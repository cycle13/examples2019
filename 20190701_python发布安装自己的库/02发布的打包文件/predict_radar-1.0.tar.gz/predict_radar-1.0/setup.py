#!/usr/bin/env python3
# -*- coding: utf-8 -*-

from distutils.core import setup

setup(
    name='predict_radar',
    version='1.0',
    description='predict_radar',
    author='sun',
    author_email='sun@supermap.com',
    url='',
    license='No License',
    platforms='python 3.6',
    py_modules=['radar_test'],
    package_dir={'': ''},
    packages=['nets', 'data_provider', 'utils', 'layers']
)
