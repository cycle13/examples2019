#coding = utf-8
from __future__ import print_function
__author__ = 'elesun'
import os.path
import time
import numpy as np
import tensorflow as tf
import cv2
import sys
import random
from nets import models_factory
from data_provider import datasets_factory
from utils import preprocess
from utils import metrics
from skimage.measure import compare_ssim
from PIL import Image
import matplotlib.pyplot as plt

os.environ["CUDA_VISIBLE_DEVICES"] = "1" #"-1" #elesun "1,0"
# -----------------------------------------------------------------------------
FLAGS = tf.app.flags.FLAGS
tf.app.flags.DEFINE_string('f', '', 'kernel')
# data I/O
tf.app.flags.DEFINE_string('dataset_name', 'radar',  #elesun radar
                           'The name of dataset.')
tf.app.flags.DEFINE_string('train_data_paths',
                           'data/radar500_train001',  # elesun radar SRAD2018_TRAIN_001_10sam  radar500_train001
                           'train data paths.')
tf.app.flags.DEFINE_string('valid_data_paths',
                           'data/radar500_train001',  # elesun radar SRAD2018_TRAIN_001_10sam  radar500_train001
                           'validation data paths.')
tf.app.flags.DEFINE_string('gen_frm_dir', 'results/radar_predrnn_pp_radar500_train001',  # elesun radar
                           'dir to store result.')
# model
tf.app.flags.DEFINE_string('model_name', 'predrnn_pp',#elesun predrnn_pp
                           'The name of the architecture.')
tf.app.flags.DEFINE_string('pretrained_model', 'model/radar_predrnn_pp', #elesun radar
                           'file of a pretrained model to initialize from.')
tf.app.flags.DEFINE_integer('input_length', 7,#elesun 10
                            'encoder hidden states.')
tf.app.flags.DEFINE_integer('seq_length', 13, #elesun 30 20
                            'total input and output length.')
tf.app.flags.DEFINE_integer('img_width', 200,#elesun radar 501
                            'input image width.')
tf.app.flags.DEFINE_integer('img_channel', 1,#elesun 1 radar channel one
                            'number of image channel.')
tf.app.flags.DEFINE_integer('stride', 1,
                            'stride of a convlstm layer.')
tf.app.flags.DEFINE_integer('filter_size', 5,
                            'filter of a convlstm layer.')
tf.app.flags.DEFINE_string('num_hidden', '128,64,64,64',
                           'COMMA separated number of units in a convlstm layer.')
tf.app.flags.DEFINE_integer('patch_size', 4,
                            'patch size on one dimension.')
tf.app.flags.DEFINE_boolean('layer_norm', True,
                            'whether to apply tensor layer norm.')
# optimization
tf.app.flags.DEFINE_integer('batch_size', 1,#elesun 8
                            'batch size for training.')


class Model(object):
    def __init__(self):
        # inputs
        self.x = tf.placeholder(tf.float32,
                                [FLAGS.batch_size,
                                 FLAGS.seq_length,
                                 FLAGS.img_width//FLAGS.patch_size,
                                 FLAGS.img_width//FLAGS.patch_size,
                                 FLAGS.patch_size*FLAGS.patch_size*FLAGS.img_channel])
        self.mask_true = tf.placeholder(tf.float32,
                                        [FLAGS.batch_size,
                                         FLAGS.seq_length-FLAGS.input_length-1,
                                         FLAGS.img_width//FLAGS.patch_size,
                                         FLAGS.img_width//FLAGS.patch_size,
                                         FLAGS.patch_size*FLAGS.patch_size*FLAGS.img_channel])
        self.pred_seq = []
        num_hidden = [int(x) for x in FLAGS.num_hidden.split(',')]
        print('num_hidden :',num_hidden)
        num_layers = len(num_hidden)
        with tf.variable_scope(tf.get_variable_scope()):
            # define a model
            output_list = models_factory.construct_model(
                FLAGS.model_name, self.x,
                self.mask_true,
                num_layers, num_hidden,
                FLAGS.filter_size, FLAGS.stride,
                FLAGS.seq_length, FLAGS.input_length,
                FLAGS.layer_norm)
            gen_ims = output_list[0]
            print ('gen_ims.shape',gen_ims.shape)#elesun gen_ims.shape (1, 19, 40, 40, 16)
            loss = output_list[1]
            pred_ims = gen_ims[:,FLAGS.input_length-1:]
            self.pred_seq.append(pred_ims)


        # session
        variables = tf.global_variables()
        self.saver = tf.train.Saver(variables)
        #init = tf.global_variables_initializer()
        configProt = tf.ConfigProto()
        configProt.gpu_options.allow_growth = True
        configProt.allow_soft_placement = True
        self.sess = tf.Session(config = configProt)
        #self.sess.run(init)
        if FLAGS.pretrained_model:
            ckpt = tf.train.get_checkpoint_state(FLAGS.pretrained_model)#./pretrained/radar_predrnn_pp by elesun not add model.ckpt
            print('ckpt.model_checkpoint_path',ckpt.model_checkpoint_path)
            self.saver.restore(self.sess, ckpt.model_checkpoint_path)
    def test(self, inputs, mask_true):
        feed_dict = {self.x: inputs}
        feed_dict.update({self.mask_true: mask_true})
        gen_ims = self.sess.run(self.pred_seq, feed_dict)
        return gen_ims

def predict(step = 3):
    if tf.gfile.Exists(FLAGS.gen_frm_dir):
        tf.gfile.DeleteRecursively(FLAGS.gen_frm_dir)
    tf.gfile.MakeDirs(FLAGS.gen_frm_dir)
    print("**********loading data**********")
    #elesun test 20190514
    test_input_handle = datasets_factory.data_provider(
        FLAGS.dataset_name, FLAGS.train_data_paths, FLAGS.valid_data_paths,
        FLAGS.batch_size, FLAGS.img_width, seq_length=FLAGS.seq_length, is_training=False)#elesun , FLAGS.seq_length
    print("**********loading network and  models**********")
    model = Model()
    print('**********predicting**********')
    test_input_handle.begin(do_shuffle = False)
    seq_id = 0
    img_mse,ssim= [],[]
    for i in range(FLAGS.seq_length - FLAGS.input_length):
        img_mse.append(0)
        ssim.append(0)
    mask_true = np.zeros((FLAGS.batch_size,
                          FLAGS.seq_length-FLAGS.input_length-1,
                          FLAGS.img_width//FLAGS.patch_size,
                          FLAGS.img_width//FLAGS.patch_size,
                          FLAGS.patch_size**2*FLAGS.img_channel))
    while(test_input_handle.no_batch_left() == False):
        seq_id = seq_id + 1
        print ('seq_id',seq_id,'is predicting')#elesun
        test_ims = test_input_handle.get_batch()
        test_dat = preprocess.reshape_patch(test_ims, FLAGS.patch_size)
        img_gen = model.test(test_dat, mask_true)

        # concat outputs of different gpus along batch
        img_gen = np.concatenate(img_gen)
        img_gen = preprocess.reshape_patch_back(img_gen, FLAGS.patch_size)
        # MSE per frame
        for i in range(FLAGS.seq_length - FLAGS.input_length):
            x = test_ims[:,i + FLAGS.input_length,:,:,0]
            gx = img_gen[:,i,:,:,0]
            gx = np.maximum(gx, 0)
            gx = np.minimum(gx, 1)
            mse = np.sum(np.square(x - gx))#elesun np.square(x - gx).sum()
            img_mse[i] += mse
            real_frm = np.uint8(x * 255)
            pred_frm = np.uint8(gx * 255)
            for b in range(FLAGS.batch_size):
                score, _ = compare_ssim(pred_frm[b],real_frm[b],full=True)
                ssim[i] += score
                #print('image',i,'batch',b,'ssim',ssim[i])
        test_frame_path_split = test_input_handle.frames_path_list[
            ((seq_id - 1) * FLAGS.batch_size) * FLAGS.seq_length].split('/')
        # save prediction examples
        if seq_id <= test_input_handle.total():  # elesun test len(self.indices)
            test_frame_path_split = test_input_handle.frames_path_list[
                ((seq_id - 1) * FLAGS.batch_size) * FLAGS.seq_length].split('/')
            path = os.path.join(FLAGS.gen_frm_dir, test_frame_path_split[2])  # elesun test RAD_206482464212530
            os.mkdir(path)
            for i in range(FLAGS.seq_length):
                if i >=  (FLAGS.input_length + step):
                    break
                name = "GT_" + (test_input_handle.frames_path_list[(((seq_id - 1) * FLAGS.batch_size) * FLAGS.seq_length) + i].split('/'))[3]  # elesun test RAD_206482464212530_000.png
                file_name = os.path.join(path, name)
                img_gt = np.uint8(test_ims[0, i, :, :, :] * 255)
                cv2.imwrite(file_name, img_gt)
                #print(file_name,'has been saved !')
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                if i >=  step :
                    break
                name = "PD_" + (test_input_handle.frames_path_list[(((seq_id - 1) * FLAGS.batch_size) * FLAGS.seq_length) + (
                                                i + FLAGS.input_length)].split('/'))[3]  # elesun test RAD_206482464212530_000.png
                file_name = os.path.join(path, name)
                img_pd = img_gen[0, i, :, :, :]
                img_pd = np.maximum(img_pd, 0)
                img_pd = np.minimum(img_pd, 1)
                img_pd = np.uint8(img_pd * 255)
                cv2.imwrite(file_name, img_pd)
                #print(file_name, 'has been saved !')
        test_input_handle.next()

    img_mse = np.asarray(img_mse, dtype=np.float32) / (FLAGS.batch_size * seq_id)
    print('mse avg per frame: ' + str(np.mean(img_mse)))
    for i in range(FLAGS.seq_length - FLAGS.input_length):
        print('frame',i+1,'mse',img_mse[i])

    ssim = np.asarray(ssim, dtype=np.float32)/(FLAGS.batch_size*seq_id)
    print('ssim avg per frame: ' + str(np.mean(ssim)))
    for i in range(FLAGS.seq_length - FLAGS.input_length):
        print('frame',i+1,'ssim',ssim[i])

def plt_show_result():
    area_file_list = os.listdir(FLAGS.gen_frm_dir)
    area_file_list.sort()  # img_list.sort(key=lambda x:int(x[4:])) #gt02.png pd16.png
    #print('area_file_list is ',area_file_list)
    img_file_path = FLAGS.gen_frm_dir + '/' + area_file_list[0]
    #print ("%s has been find!"%img_file_path)
    img_list = os.listdir(img_file_path)
    img_list.sort()  # img_list.sort(key=lambda x:int(x[4:])) #gt02.png pd16.png
    #print('img_list is ',img_list)
    #print('num of file =',len(img_list))
    plt.figure("%s"%area_file_list[0],figsize=(3,12))
    j = 0
    for i, imgname in enumerate(img_list):
        img_path = ''
        img_path = img_file_path + '/' + imgname
        img = Image.open(img_path)
        #print ("%s has been find!"%imgname)
        #print ("%s has been find!"%img_path)
        #print(FLAGS.input_length+(len(img_list) - FLAGS.input_length)/2)
        if (imgname[0:2] == 'GT'):
            plt.subplot((FLAGS.input_length+(len(img_list) - FLAGS.input_length)/2), 2, 2*i+1)
        elif (imgname[0:2] == 'PD'):
            j = j + 1
            plt.subplot((FLAGS.input_length+(len(img_list) - FLAGS.input_length)/2), 2, 2*FLAGS.input_length+2*j)
        plt.title(imgname[0:2]+imgname[23:26])
        plt.imshow(img)
        plt.axis('off')

    #plt.subplots_adjust(wspace=0.0, hspace=0.0)
    plt.savefig("result.jpg")
    plt.show()

if __name__ == '__main__':
    predict(step = 6)
    plt_show_result()