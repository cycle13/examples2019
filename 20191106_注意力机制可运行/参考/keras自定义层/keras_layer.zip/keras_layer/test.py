# -*- coding: utf-8 -*-
from __future__ import print_function
__author__ = 'elesun'
#from custom_layers import Scale
from user_layer import Scale
print("hello")

