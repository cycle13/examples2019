"""radar predict trian and test by sunfengzhen"""
env:
	Linux ubuntu 4.4.0-31-generic x86_64 GNU;python 2.7;tensorflow1.10.1;Keras2.2.4
	matplotlib2.2.3

cmd:
	scp
	$cd /home/sun/sun/multi_radar_conv_lstm_500x500
	$scp -r multi_radar_conv_lstm_500x500  sunfengzhen@148.70.23.92:/home/sunfengzhen/sun

	run
	sun@ubuntu:~/sun/radar_conv_lstm_501x501$ nohup python2 main_radar.py >out.log &

structure:
	data --source datasets like RAD_32528
	model -- saved trianed model
	output -- output constrast img
	main_radar.py -- main function control by mode test or train
	conv_lstm_network.py -- network disctption
	model_evaluate_predict.py -- load model and test
	preprocessing.py -- load dataset and process
