#coding = utf-8
from __future__ import print_function
__author__ = 'elesun'
import numpy as np
import os
import cv2
from PIL import Image
import logging
import random
import tensorflow as tf
import time

logger = logging.getLogger(__name__)

class InputHandle:
    def __init__(self, datas, indices, frames_path_list, input_param):#elesun test
        self.name = input_param['name']
        self.input_data_type = input_param.get('input_data_type', 'float32')
        self.minibatch_size = input_param['minibatch_size']
        self.image_width = input_param['image_width']
        self.channel = input_param['channel']
        self.datas = datas
        self.indices = indices
        self.frames_path_list = frames_path_list #elesun test
        self.current_position = 0
        self.current_batch_indices = []
        self.current_input_length = input_param['seq_length']
        self.interval = 1 #elesun 2

    def total(self):
        return len(self.indices)

    def begin(self, do_shuffle=True):
        logger.info("Initialization for read data ")
        if do_shuffle:
            random.shuffle(self.indices)
        self.current_position = 0
        self.current_batch_indices = self.indices[self.current_position:self.current_position + self.minibatch_size]

    def next(self):
        self.current_position += self.minibatch_size
        if self.no_batch_left():
            return None
        self.current_batch_indices = self.indices[self.current_position:self.current_position + self.minibatch_size]

    def no_batch_left(self):
        if self.current_position + self.minibatch_size > self.total():
            return True
        else:
            return False

    def get_batch(self):
        if self.no_batch_left():
            logger.error(
                "There is no batch left in " + self.name + ". Consider to user iterators.begin() to rescan from the beginning of the iterators")
            return None
        input_batch = np.zeros(
            (self.minibatch_size, self.current_input_length, self.image_width, self.image_width, self.channel)).astype(
            self.input_data_type)
        for i in range(self.minibatch_size):
            batch_ind = self.current_batch_indices[i]
            begin = batch_ind
            end = begin + self.current_input_length * self.interval
            data_slice = self.datas[begin:end:self.interval]
            #print ('data_slice.shape :',data_slice.shape) #elesun
            input_batch[i, :self.current_input_length, :, :, :] = data_slice #elesun , :, :, :]
            # logger.info('data_slice shape')
            # logger.info(data_slice.shape)
            # logger.info(input_batch.shape)
        input_batch = input_batch.astype(self.input_data_type)
        return input_batch

    def print_stat(self):
        logger.info("Iterator Name: " + self.name)
        logger.info("    current_position: " + str(self.current_position))
        logger.info("    Minibatch Size: " + str(self.minibatch_size))
        logger.info("    total Size: " + str(self.total()))
        logger.info("    current_input_length: " + str(self.current_input_length))
        logger.info("    Input Data Type: " + str(self.input_data_type))

class DataProcess:
    def __init__(self, input_param):
        self.input_param = input_param
        self.paths = input_param['paths']
        self.image_width = input_param['image_width']
        self.seq_len = input_param['seq_length']

    def load_data(self, paths, mode='train'):
        data_dir = paths[0]
        intervel = 1 #elesun 2

        frames_np = []
        #data/radar500_train001/RAD_296582464212530/RAD_296582464212530_020.png
 #data/SRAD2018_TRAIN_001_10sam/RAD_206482464212545/RAD_206482464212545_060.png
        if mode == 'train':
            subjects = ['1', '2', '3','4', '5', '6', '7', '8'] #elesun
        elif mode == 'test':
            subjects = ['0', '9'] #elesun
        else:
            print ("MODE ERROR")
        print ('**************mode:', mode, '**************')
        _path = data_dir
        print ('load data...', _path)
        areanames = os.listdir(_path) #elesun RAD_296582464212530
        areanames.sort()
        print ('data areas ', len(areanames))
        frames_file_name = []
        for areaname in areanames: #elesun RAD_296582464212530
            area_path = os.path.join(_path, areaname)#data/radar500_train001/RAD_296582464212530
            subject = areaname[-1] #elesun last num 0-9
            if subject not in subjects:#3 5 7 for test model
                continue
            filenames = os.listdir(area_path)  #RAD_296582464212530_020.png
            filenames.sort()
            #print ('data frames ', len(filenames))# 61 frames
            for filename in filenames:
            #data/radar500_train001/RAD_296582464212530/RAD_296582464212530_020.png
                #print('filename',filename)
                #print('filename[-7:-4]', filename[-7:-4])
                if (int(filename[-7:-4])%3) != 0 :#elesun interval
                    #print('filename', filename)
                    continue
                file_path = os.path.join(area_path, filename)
                #cv2.imread('test.jpg') # BGR
                image = cv2.cvtColor(cv2.imread(file_path), cv2.COLOR_BGR2GRAY)
                #cv2.COLOR_BGR2GRAY  cv2.COLOR_BGR2RGB elesun channel three
                #image = cv2.imread(file_path,cv2.IMREAD_GRAYSCALE) #elesun cv2.IMREAD_COLOR cv2.IMREAD_GRAYSCALE
                #print ('image.shape :',image.shape)#[501,501,3]
                #image = image[image.shape[0]//4:-image.shape[0]//4, image.shape[1]//4:-image.shape[1]//4, :] #cut center for RGB
                #image = image[image.shape[0]//4:-image.shape[0]//4, image.shape[1]//4:-image.shape[1]//4] #cut center for gray
                if self.image_width != image.shape[0]:
                    image = cv2.resize(image, (self.image_width, self.image_width))
                #frames_np.append(np.array(image, dtype=np.float32) / 255.0)
                image_np = np.array(image, dtype=np.float32) / 255.0 #elesun
                image_np = image_np.reshape(self.image_width,self.image_width,1) #elesun
                #print ('image_np.shape :',image_np.shape) #elesun
                #print ('image_np :',image_np) #elesun
                frames_np.append(image_np)
                #print('filename :', filename)  # elesun
                frames_file_name.append(file_path) #elesun
                #print ('file_path :',file_path) #elesun
                #time.sleep(0.1)  # elesun debug
        # is it a begin index of sequence
        indices = []
        index = 0
        print ('gen index')
        print ('len(frames_file_name) :',len(frames_file_name))#elesun
        while index + intervel * self.seq_len - 1 < len(frames_file_name):
            # data/radar500_train001/RAD_296582464212530/RAD_296582464212530_020.png
            start_infos = frames_file_name[index].split('/')
            end_infos = frames_file_name[index+intervel*(self.seq_len-1)].split('/')
            #must be same area and same sequence
            #RAD_296582464212530   RAD_296582464212530_020.png
            #print ('start_infos',start_infos) #elesun debug
            #print ('end_infos',end_infos) #elesun debug
            #print('start_infos[3]', start_infos[3])  # elesun debug
            if start_infos[2] != end_infos[2]:
                index += 1
                continue
            #print('start_infos[3]', start_infos[3])  # elesun debug RAD_296582464212530_020.png
            start_frame_idstr = start_infos[3].split('_')#RAD 296582464212530 020.png
            end_frame_idstr= end_infos[3].split('_')
            #print('start_frame_idstr[2]', start_frame_idstr[2])  # elesun debug 020.png
            #print('end_frame_idstr[2]', end_frame_idstr[2])  # elesun debug 020.png
            start_frame_id = start_frame_idstr[2].split('.')
            end_frame_id = end_frame_idstr[2].split('.')
            #print('start_frame_id[0]', start_frame_id[0])  # elesun debug 001
            #print('end_frame_id[0]', end_frame_id[0])  # elesun debug
            #print('self.seq_len :', self.seq_len)  # elesun
            #print('1 * (self.seq_len - 1) * intervel :', (1 * (self.seq_len - 1) * intervel))  # elesun
            #follow 1 for lianxu frame; intervel is 2
            if int(end_frame_id[0]) - int(start_frame_id[0]) == 3 * (self.seq_len - 1) * intervel: #elesun interval
                indices.append(index)
                #print ('index append:', index)  # elesun
            #time.sleep(1)  # elesun debug
            index += 1
        print("there are " + str(len(indices)) + " sequences")
        #print("indices is ",indices)#elesun test
        # data = np.asarray(frames_np)
        data = frames_np
        print("there are " + str(len(data)) + " pictures")
        return data, indices, frames_file_name #elesun test

    def get_train_input_handle(self):
        train_data, train_indices, train_frames_path_list = self.load_data(self.paths, mode='train')#elesun test
        return InputHandle(train_data, train_indices, train_frames_path_list, self.input_param)

    def get_test_input_handle(self):
        #test_data, test_indices = self.load_data(self.paths, mode='test')
        test_data, test_indices, test_frames_path_list = self.load_data(self.paths, mode='test')#elesun test
        return InputHandle(test_data, test_indices, test_frames_path_list, self.input_param)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_dir", type=str)
    parser.add_argument("output_dir", type=str)
    args = parser.parse_args()

    partition_names = ['train', 'test']
    partition_fnames = partition_data(args.input_dir)


if __name__ == '__main__':
    main()
