# -*- coding: utf-8 -*-
from __future__ import print_function
__author__ = 'elesun'
import numpy as np
import os
import cv2
from PIL import Image
import logging
import random
import tensorflow as tf
import time
import re

logger = logging.getLogger(__name__)

class InputHandle:
    def __init__(self, datas, indices, frames_path_list, input_param):#elesun test
        self.name = input_param['name']
        self.input_data_type = input_param.get('input_data_type', 'float32')
        self.minibatch_size = input_param['minibatch_size']
        self.image_width = input_param['image_width']
        self.channel = input_param['channel']
        self.datas = datas
        self.indices = indices
        self.frames_path_list = frames_path_list #elesun test
        self.current_position = 0
        self.current_batch_indices = []
        self.current_input_length = input_param['seq_length']
        self.interval = 1 #elesun 2

    def total(self):
        return len(self.indices)

    def begin(self, do_shuffle=True):
        logger.info("Initialization for read data ")
        if do_shuffle:
            random.shuffle(self.indices)
        self.current_position = 0
        self.current_batch_indices = self.indices[self.current_position:self.current_position + self.minibatch_size]

    def next(self):
        self.current_position += self.minibatch_size
        if self.no_batch_left():
            return None
        self.current_batch_indices = self.indices[self.current_position:self.current_position + self.minibatch_size]

    def no_batch_left(self):
        if self.current_position + self.minibatch_size > self.total():
            return True
        else:
            return False

    def get_batch(self):
        if self.no_batch_left():
            logger.error(
                "There is no batch left in " + self.name + ". Consider to user iterators.begin() to rescan from the beginning of the iterators")
            return None
        input_batch = np.zeros(
            (self.minibatch_size, self.current_input_length, self.image_width, self.image_width, self.channel)).astype(
            self.input_data_type)
        for i in range(self.minibatch_size):
            batch_ind = self.current_batch_indices[i]
            begin = batch_ind
            end = begin + self.current_input_length * self.interval
            data_slice = self.datas[begin:end:self.interval]
            #print ('data_slice.shape :',data_slice.shape) #elesun
            input_batch[i, :self.current_input_length, :, :, :] = data_slice #elesun , :, :, :]
            # logger.info('data_slice shape')
            # logger.info(data_slice.shape)
            # logger.info(input_batch.shape)
        input_batch = input_batch.astype(self.input_data_type)
        return input_batch

    def print_stat(self):
        print("Iterator Name: " + self.name) # logger.info
        print("    current_position: " + str(self.current_position)) # logger.info
        print("    Minibatch Size: " + str(self.minibatch_size)) # logger.info
        print("    total Size: " + str(self.total())) # logger.info
        print("    current_input_length: " + str(self.current_input_length)) # logger.info
        print("    Input Data Type: " + str(self.input_data_type)) # logger.info

class DataProcess:
    def __init__(self, input_param):
        self.input_param = input_param
        self.paths = input_param['paths']
        self.image_width = input_param['image_width']
        self.seq_len = input_param['seq_length']

    def load_data(self, paths, mode='train'):
        intervel = 6
        frames_file_name = []  # 用于保存符合要求可用的文件路径列表
        frames_np = []  # 用于保存符合要求可用的文件数据列表
        indices = []
        index = 0
        # /home/data/sfz/data_typhoon/rgb/train/A_Hour_1760.png
        if mode == 'train':#
            print('**************mode:', mode, '**************')
            in_dir = "".join(paths[0]) # elesun path  paths[0] '../../../data/sfz/data_typhoon/rgb/train'
            for i_train in range(intervel-2) : #intervel-1 0 1 2 3 4
                print('time %02d load data from dir :'%(i_train+1), in_dir)
                png_file_list = os.listdir(in_dir)
                A_temp_list = []
                for index_testset, png_filename in enumerate(png_file_list):
                    if ("".join(re.findall("^[A-Z]", png_filename))) == "A":
                        A_temp_list.append(png_filename)
                A_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
                # print('A_temp_list is ', A_temp_list)
                B_temp_list = []
                for index_testset, png_filename in enumerate(png_file_list):
                    if ("".join(re.findall("^[A-Z]", png_filename))) == "B":
                        B_temp_list.append(png_filename)
                B_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
                # print('B_temp_list is ', B_temp_list)
                C_temp_list = []
                for index_testset, png_filename in enumerate(png_file_list):
                    if ("".join(re.findall("^[A-Z]", png_filename))) == "C":
                        C_temp_list.append(png_filename)
                C_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
                # print('C_temp_list is ', C_temp_list)
                png_file_list = C_temp_list + B_temp_list + A_temp_list
                # print('png_file_list is ', png_file_list)
                print('num of png_file_list =', len(png_file_list))
                cur_seq_valid = True
                for index_set, png_filename in enumerate(png_file_list):
                    file_path = os.path.join(in_dir, png_filename)
                    #print("%s has been found!" % file_path)
                    seqence_num = re.findall("^[A-Z]", png_filename)
                    seqence_num = "".join(seqence_num)
                    #print("seqence_num is", seqence_num)
                    hour_num = re.findall("(?<=Hour_).*(?=.png)", png_filename)
                    hour_num = int("".join(hour_num))
                    #print("hour_num is", hour_num)

                    last_seqence_num = re.findall("^[A-Z]", png_file_list[index_set - 1])
                    last_seqence_num = "".join(last_seqence_num)
                    #print("last_seqence_num is", last_seqence_num)
                    last_hour_num = re.findall("(?<=Hour_).*(?=.png)", png_file_list[index_set - 1])
                    last_hour_num = int("".join(last_hour_num))
                    #print("last_hour_num is", last_hour_num)

                    if (index != 0) : #排除第一个异常
                        if (seqence_num != last_seqence_num) or (hour_num != last_hour_num + 1) :
                            #最后几个数据强制做无效处理
                            cur_seq_valid = False
                            #print("cur_seq_valid = False")

                    if hour_num%intervel == i_train :
                        # /home/data/sfz/data_typhoon/rgb/train/A_Hour_1760.png
                        # cv2.imread('test.jpg') # BGR
                        image = cv2.cvtColor(cv2.imread(file_path), cv2.COLOR_BGR2RGB)
                        # cv2.COLOR_BGR2GRAY  cv2.COLOR_BGR2RGB elesun channel three
                        # image = cv2.imread(file_path,cv2.IMREAD_GRAYSCALE) #elesun cv2.IMREAD_COLOR cv2.IMREAD_GRAYSCALE
                        #print('image.shape :', image.shape)  # [501,501,3]
                        if self.image_width != image.shape[0]:
                            image = cv2.resize(image, (self.image_width, self.image_width))
                        image_np = np.array(image, dtype=np.float32) / 255.0  # elesun
                        #image_np = image_np.reshape(self.image_width, self.image_width, 1)  # elesun
                        #print('image_np.shape :', image_np.shape)  # elesun
                        # print ('image_np :',image_np) #elesun
                        frames_np.append(image_np)
                        frames_file_name.append(file_path)  # elesun
                        # print ('file_path :',file_path) #elesun
                        if index % self.seq_len == self.seq_len-1 and cur_seq_valid == True:
                            indices.append(index-self.seq_len+1)
                            #print('index-self.seq_len+1 append:', index-self.seq_len+1)
                        if cur_seq_valid == False :
                            index = indices[-1] + self.seq_len
                            del (frames_np[indices[-1]+self.seq_len:-1])
                            del (frames_file_name[indices[-1]+self.seq_len:-1])
                            #print("length frames_np",len(frames_np))
                            #print("length frames_file_name", len(frames_file_name))
                            cur_seq_valid = True
                            #print("cur_seq_valid = True")
                        #print("index", index)
                        index += 1
            del (frames_np[indices[-1] + self.seq_len:])  # 最终，把多余的矩阵尾巴炸掉
            del (frames_file_name[indices[-1] + self.seq_len:])  # 最终，把多余的矩阵尾巴炸掉
            # for index_name,str_name in enumerate(frames_file_name) : # [::12] :# 每间隔seq取一次数
            #    print(index_name,str_name.split('/')[-1], end = '\n')#只提取文件名 hour1-hour7...-hour67 seq0 || seq1 from hour73
        elif mode == 'test':
            print('**************mode:', mode, '**************')
            #print("paths",paths) # elesun path
            in_dir = "".join(paths[0]) # elesun path
            print('load data from dir :', in_dir)
            png_file_list = os.listdir(in_dir)
            #print("png_file_list",png_file_list)
            i_train = intervel - 1
            A_temp_list = []
            for index_testset, png_filename in enumerate(png_file_list):
                if ("".join(re.findall("^[A-Z]", png_filename))) == "A":
                    A_temp_list.append(png_filename)
            A_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
            #print('A_temp_list is ', A_temp_list)
            B_temp_list = []
            for index_testset, png_filename in enumerate(png_file_list):
                if ("".join(re.findall("^[A-Z]", png_filename))) == "B":
                    B_temp_list.append(png_filename)
            B_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
            # print('B_temp_list is ', B_temp_list)
            C_temp_list = []
            for index_testset, png_filename in enumerate(png_file_list):
                if ("".join(re.findall("^[A-Z]", png_filename))) == "C":
                    C_temp_list.append(png_filename)
            C_temp_list.sort(key=lambda x: int("".join(re.findall("(?<=Hour_).*(?=.png)", x))))
            # print('C_temp_list is ', C_temp_list)
            png_file_list = C_temp_list + B_temp_list + A_temp_list
            # print('png_file_list is ', png_file_list)
            print('num of png_file_list =', len(png_file_list))
            cur_seq_valid = True
            for index_set, png_filename in enumerate(png_file_list):
                file_path = os.path.join(in_dir, png_filename)
                # print("%s has been found!" % file_path)
                seqence_num = re.findall("^[A-Z]", png_filename)
                seqence_num = "".join(seqence_num)
                # print("seqence_num is", seqence_num)
                hour_num = re.findall("(?<=Hour_).*(?=.png)", png_filename)
                hour_num = int("".join(hour_num))
                # print("hour_num is", hour_num)

                last_seqence_num = re.findall("^[A-Z]", png_file_list[index_set - 1])
                last_seqence_num = "".join(last_seqence_num)
                # print("last_seqence_num is", last_seqence_num)
                last_hour_num = re.findall("(?<=Hour_).*(?=.png)", png_file_list[index_set - 1])
                last_hour_num = int("".join(last_hour_num))
                # print("last_hour_num is", last_hour_num)

                if (index != 0):  # 排除第一个异常
                    if (seqence_num != last_seqence_num) or (hour_num != last_hour_num + 1):
                        # 最后几个数据强制做无效处理
                        cur_seq_valid = False
                        # print("cur_seq_valid = False")

                if hour_num % intervel == i_train:
                    # /home/data/sfz/data_typhoon/rgb/train/A_Hour_1760.png
                    # cv2.imread('test.jpg') # BGR
                    image = cv2.cvtColor(cv2.imread(file_path), cv2.COLOR_BGR2RGB)
                    # cv2.COLOR_BGR2GRAY  cv2.COLOR_BGR2RGB elesun channel three
                    # image = cv2.imread(file_path,cv2.IMREAD_GRAYSCALE) #elesun cv2.IMREAD_COLOR cv2.IMREAD_GRAYSCALE
                    # print('image.shape :', image.shape)  # [501,501,3]
                    if self.image_width != image.shape[0]:
                        image = cv2.resize(image, (self.image_width, self.image_width))
                    image_np = np.array(image, dtype=np.float32) / 255.0  # elesun
                    # image_np = image_np.reshape(self.image_width, self.image_width, 1)  # elesun
                    # print('image_np.shape :', image_np.shape)  # elesun
                    # print ('image_np :',image_np) #elesun
                    frames_np.append(image_np)
                    frames_file_name.append(file_path)  # elesun
                    # print ('file_path :',file_path) #elesun
                    if index % self.seq_len == self.seq_len - 1 and cur_seq_valid == True:
                        indices.append(index - self.seq_len + 1)
                        # print('index-self.seq_len+1 append:', index - self.seq_len + 1)
                    if cur_seq_valid == False:
                        index = indices[-1] + self.seq_len
                        del (frames_np[indices[-1] + self.seq_len:-1])
                        del (frames_file_name[indices[-1] + self.seq_len:-1])
                        # print("length frames_np", len(frames_np))
                        # print("length frames_file_name", len(frames_file_name))
                        cur_seq_valid = True
                        # print("cur_seq_valid = True")
                    # print("index", index)
                    index += 1
            del (frames_np[indices[-1] + self.seq_len:])  # 最终，把多余的矩阵尾巴炸掉
            del (frames_file_name[indices[-1] + self.seq_len:])  # 最终，把多余的矩阵尾巴炸掉
            # for index_name,str_name in enumerate(frames_file_name) : # [::12] :# 每间隔seq取一次数
            #    print(index_name,str_name.split('/')[-1], end = '\n')#只提取文件名 hour1-hour7...-hour67 seq0 || seq1 from hour73
        else:
           print ("MODE ERROR")
        #print("indices is ",indices)#elesun
        print("there are " + str(len(indices)) + " sequences")
        #print("frames_file_name is ", frames_file_name)  # elesun
        print("\nthere are " + str(len(frames_file_name)) + " files in frames_file_name")
        data = np.asarray(frames_np)
        #data = frames_np
        print("data.shape",data.shape)
        print("there are " + str(len(frames_np)) + " pictures in frames_np")
        return frames_np, indices, frames_file_name

    def get_train_input_handle(self):
        train_data, train_indices, train_frames_path_list = self.load_data(self.paths, mode='train')#elesun test
        return InputHandle(train_data, train_indices, train_frames_path_list, self.input_param)

    def get_test_input_handle(self):
        #test_data, test_indices = self.load_data(self.paths, mode='test')
        test_data, test_indices, test_frames_path_list = self.load_data(self.paths, mode='test')#elesun test
        return InputHandle(test_data, test_indices, test_frames_path_list, self.input_param)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("input_dir", type=str)
    parser.add_argument("output_dir", type=str)
    args = parser.parse_args()

    partition_names = ['train', 'test']
    partition_fnames = partition_data(args.input_dir)


if __name__ == '__main__':
    main()
