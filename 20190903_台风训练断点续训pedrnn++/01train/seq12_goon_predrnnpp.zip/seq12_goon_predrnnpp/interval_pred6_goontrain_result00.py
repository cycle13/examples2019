# -*- coding: utf-8 -*-
from __future__ import print_function
__author__ = 'elesun'
import os.path
import time
import numpy as np
import tensorflow as tf
import cv2
import sys
import random
from nets import models_factory
from data_provider import datasets_factory
from utils import preprocess
from utils import metrics
from skimage.measure import compare_ssim
import psutil

os.environ["CUDA_VISIBLE_DEVICES"] = "0" #"1,0"
# -----------------------------------------------------------------------------
FLAGS = tf.app.flags.FLAGS

# data I/O
tf.app.flags.DEFINE_string(#'dataset_name', 'mnist',  #elesun mnist
                           #'dataset_name', 'taxibj',  #elesun taxibj
                           #'dataset_name', 'human',  #elesun human
                           #'dataset_name', 'kth',  #elesun kth
                           #'dataset_name', 'radar',  #elesun radar
                           'dataset_name', 'typhoon',  #elesun typhoon
                           'The name of dataset.')
tf.app.flags.DEFINE_string('train_data_paths',
                           #'data/moving-mnist-example/moving-mnist-train.npz',  #elesun mnist
                           #'data/TaxiBJ',  # elesun taxibj
                           #'data/human',  # elesun human
                           #'data/kth',  # elesun kth
                           #'data/radar500_train001',  # elesun radar SRAD2018_TRAIN_001_10sam  radar500_train001
                           '../../../data/sfz/data_typhoon/rgb/train',   # elesun typhoon
                           'train data paths.')
tf.app.flags.DEFINE_string('valid_data_paths',
                           #'data/moving-mnist-example/moving-mnist-valid.npz',#elesun mnist
                           #'data/TaxiBJ',  #elesun taxibj
                           #'data/human',  # elesun human
                           #'data/kth',  # elesun kth
                           #'data/radar500_train001',  # elesun radar SRAD2018_TRAIN_001_10sam  radar500_train001
                           '../../../data/sfz/data_typhoon/rgb/train',# elesun typhoon test_process
                           'validation data paths.')
tf.app.flags.DEFINE_string(#'save_dir', 'checkpoints/mnist_predrnn_pp',#elesun mnist
                           #'save_dir', 'checkpoints/taxibj_predrnn_pp',#elesun taxibj
                           #'save_dir', 'checkpoints/human_predrnn_pp',  # elesun human
                           #'save_dir', 'checkpoints/kth_predrnn_pp',  # elesun kth
                           #'save_dir', 'checkpoints/radar_predrnn_pp',  # elesun radar
                           'save_dir', 'checkpoints/typhoon_predrnn_pp',  # elesun typhoon
                            'dir to store trained net.')
tf.app.flags.DEFINE_string(#'gen_frm_dir', 'results/mnist_predrnn_pp',#elesun mnist
                           #'gen_frm_dir', 'results/taxibj_predrnn_pp',#elesun taxibj
                           #'gen_frm_dir', 'results/human_predrnn_pp',#elesun human
                           #'gen_frm_dir', 'results/kth_predrnn_pp',  # elesun kth
                           #'gen_frm_dir', 'results/radar_predrnn_pp_radar500_train001',  # elesun radar
                           'gen_frm_dir', 'results/typhoon_predrnn_pp',  # elesun typhoon
                           'dir to store result.')
# model
tf.app.flags.DEFINE_string('model_name', 'predrnn_pp',#elesun predrnn_pp
                           #'model_name', 'predrnn_pp',#elesun predrnn_pp
                           'The name of the architecture.')
tf.app.flags.DEFINE_string('pretrained_model','',#elesun no pretrained_model
                           #'pretrained_model', 'pretrained/checkpoints/mnist_mim', #elesun mnist
                           #'pretrained_model', 'pretrained/checkpoints/TaxiBJ_mim', #elesun taxibj
                           #'pretrained_model', 'pretrained/radar_predrnn_pp', #elesun radar
                           'file of a pretrained model to initialize from.')
tf.app.flags.DEFINE_integer('input_length', 6,#elesun 11
                            'encoder hidden states.')
tf.app.flags.DEFINE_integer('seq_length', 12, #elesun 21
                            'total input and output length.')
tf.app.flags.DEFINE_integer(#'img_width', 64,#elesun mnist
                            #'img_width', 32,#elesun taxibj
                            #'img_width', 32,#elesun human
                            #'img_width', 32,#elesun kth 128 fail;
                            #'img_width', 200,#elesun radar 100ok 200ok
                            'img_width', 400,#elesun typhoon 200ok 500x 300x 250xshape 260ok 280ok
                            'input image width.')
tf.app.flags.DEFINE_integer(#'im_channel', 1,#elesun 1 mnist
                            #'img_channel', 2,#elesun 2 taxibj
                            #'img_channel', 3,  # elesun 3 human
                            #'img_channel', 3,#elesun 1 kth
                            #'img_channel', 1,#elesun 1 radar channel one
                            'img_channel', 3,#elesun typhoon rgb
                            'number of image channel.')
tf.app.flags.DEFINE_integer('stride', 1,
                            'stride of a convlstm layer.')
tf.app.flags.DEFINE_integer('filter_size', 5,
                            'filter of a convlstm layer.')
tf.app.flags.DEFINE_string('num_hidden', '128,64,64,64',
                           'COMMA separated number of units in a convlstm layer.')
tf.app.flags.DEFINE_integer('patch_size', 4, # 4
                            'patch size on one dimension.')
tf.app.flags.DEFINE_boolean('layer_norm', True,
                            'whether to apply tensor layer norm.')
# optimization
tf.app.flags.DEFINE_float('lr', 0.0001,#elesun 0.001
                          'base learning rate.')
tf.app.flags.DEFINE_boolean('reverse_input', False,#True elesun
                            'whether to reverse the input frames while training.')
tf.app.flags.DEFINE_integer('batch_size', 1,#elesun 4xx  2ok
                            'batch size for training.')
tf.app.flags.DEFINE_integer('max_iterations', 100000,#elesun 200000
                            'max num of steps.')
tf.app.flags.DEFINE_integer('display_interval', 100,#elesun 100
                            'number of iters showing training loss.')
tf.app.flags.DEFINE_integer('test_interval', 100,#elesun 1000
                            'number of iters for test.')


class Model(object):
    def __init__(self):
        # inputs
        self.x = tf.placeholder(tf.float32,
                                [FLAGS.batch_size,
                                 FLAGS.seq_length,
                                 FLAGS.img_width/FLAGS.patch_size,
                                 FLAGS.img_width/FLAGS.patch_size,
                                 FLAGS.patch_size*FLAGS.patch_size*FLAGS.img_channel])
        #print('self.x.shape.as_list() :', self.x.shape.as_list())  # elesun
        self.mask_true = tf.placeholder(tf.float32,
                                        [FLAGS.batch_size,
                                         FLAGS.seq_length-FLAGS.input_length-1,
                                         FLAGS.img_width/FLAGS.patch_size,
                                         FLAGS.img_width/FLAGS.patch_size,
                                         FLAGS.patch_size*FLAGS.patch_size*FLAGS.img_channel])
        #print('self.mask_true.shape.as_list() :', self.mask_true.shape.as_list())  # elesun
        grads = []
        loss_train = []
        self.global_step = 1 #elesun goon training
        self.pred_seq = []
        self.tf_lr = tf.placeholder(tf.float32, shape=[])
        num_hidden = [int(x) for x in FLAGS.num_hidden.split(',')]
        print('num_hidden :',num_hidden)
        num_layers = len(num_hidden)
        with tf.variable_scope(tf.get_variable_scope()):
            # define a model
            output_list = models_factory.construct_model(
                FLAGS.model_name, self.x,
                self.mask_true,
                num_layers, num_hidden,
                FLAGS.filter_size, FLAGS.stride,
                FLAGS.seq_length, FLAGS.input_length,
                FLAGS.layer_norm)
            gen_ims = output_list[0]
            loss = output_list[1]
            pred_ims = gen_ims[:,FLAGS.input_length-1:]
            self.loss_train = loss / FLAGS.batch_size
            # gradients
            all_params = tf.trainable_variables()
            grads.append(tf.gradients(loss, all_params))
            self.pred_seq.append(pred_ims)

        self.train_op = tf.train.AdamOptimizer(FLAGS.lr).minimize(loss)

        # session
        variables = tf.global_variables()
        self.saver = tf.train.Saver(variables)
        init = tf.global_variables_initializer()
        configProt = tf.ConfigProto()
        configProt.gpu_options.allow_growth = True
        configProt.allow_soft_placement = True
        self.sess = tf.Session(config = configProt)
        self.sess.run(init)
        #goon training elesun
        ckpt = tf.train.get_checkpoint_state(FLAGS.save_dir)
        if ckpt and ckpt.model_checkpoint_path:
            print('ckpt.model_checkpoint_path',ckpt.model_checkpoint_path)
            self.saver.restore(self.sess, ckpt.model_checkpoint_path)
            self.global_step = int(ckpt.model_checkpoint_path.split('/')[-1].split('-')[-1])#elesun goon training
            print('global_step restore from checkpoint',self.global_step)

    def train(self, inputs, lr, mask_true):
        feed_dict = {self.x: inputs}
        #print('inputs.shape :', inputs.shape)  # elesun
        feed_dict.update({self.tf_lr: lr})
        feed_dict.update({self.mask_true: mask_true})
        loss, _ = self.sess.run((self.loss_train, self.train_op), feed_dict)
        return loss

    def test(self, inputs, mask_true):
        feed_dict = {self.x: inputs}
        feed_dict.update({self.mask_true: mask_true})
        gen_ims = self.sess.run(self.pred_seq, feed_dict)
        return gen_ims

    def save(self, itr, avg_mse): # model elesun
        checkpoint_path = os.path.join(FLAGS.save_dir, 'model.ckpt'+'mse'+str(avg_mse))
        self.saver.save(self.sess, checkpoint_path, global_step=itr)
        print('saved to ' + FLAGS.save_dir)

def main(argv=None):
    # elesun goon training
    if not tf.gfile.Exists(FLAGS.save_dir):
           tf.gfile.MakeDirs(FLAGS.save_dir)
    if not tf.gfile.Exists(FLAGS.gen_frm_dir):
           tf.gfile.MakeDirs(FLAGS.gen_frm_dir)

    # load data
    print ('pid memory used = ', round((psutil.Process(os.getpid()).memory_info().rss)
                                / 1024.0 / 1024.0 / 1024.0,2), 'Gbytes') #elesun
    train_input_handle, test_input_handle = datasets_factory.data_provider(
        FLAGS.dataset_name, FLAGS.train_data_paths, FLAGS.valid_data_paths,
        FLAGS.batch_size, FLAGS.img_width)#elesun , FLAGS.seq_length
    print ('pid memory used = ', round((psutil.Process(os.getpid()).memory_info().rss)
                                / 1024.0 / 1024.0 / 1024.0,2), 'Gbytes') #elesun
    print("Initializing models")
    model = Model()
    lr = FLAGS.lr

    delta = 0.00002
    base = 0.99998
    eta = 1
    metric_value = 1000  # 1000 model elesun 指标参考值mse

    for itr in range(model.global_step+1, FLAGS.max_iterations + 1):#elesun goon training 1
        if train_input_handle.no_batch_left():
            train_input_handle.begin(do_shuffle=True)
        ims = train_input_handle.get_batch()
        #print ('before preprocess ims.shape=', ims.shape)  # elesun
        #before preprocess ims.shape= (8, 20, 64, 64, 1)
        ims = preprocess.reshape_patch(ims, FLAGS.patch_size)
        #print ('after  preprocess ims.shape=', ims.shape) #elesun
        #after preprocess ims.shape = (8, 20, 16, 16, 16)
        if itr < 50000:
            eta -= delta
        else:
            eta = 0.0
        random_flip = np.random.random_sample(
            (FLAGS.batch_size,FLAGS.seq_length-FLAGS.input_length-1))
        true_token = (random_flip < eta)
        #true_token = (random_flip < pow(base,itr))
        ones = np.ones((FLAGS.img_width/FLAGS.patch_size,
                        FLAGS.img_width/FLAGS.patch_size,
                        FLAGS.patch_size**2*FLAGS.img_channel))
        zeros = np.zeros((FLAGS.img_width/FLAGS.patch_size,
                          FLAGS.img_width/FLAGS.patch_size,
                          FLAGS.patch_size**2*FLAGS.img_channel))
        mask_true = []
        for i in range(FLAGS.batch_size):
            for j in range(FLAGS.seq_length-FLAGS.input_length-1):
                if true_token[i,j]:
                    mask_true.append(ones)
                else:
                    mask_true.append(zeros)
        mask_true = np.array(mask_true)
        mask_true = np.reshape(mask_true, (FLAGS.batch_size,
                                           FLAGS.seq_length-FLAGS.input_length-1,
                                           FLAGS.img_width/FLAGS.patch_size,
                                           FLAGS.img_width/FLAGS.patch_size,
                                           FLAGS.patch_size**2*FLAGS.img_channel))
        cost = model.train(ims, lr, mask_true) #elesun not train only test
        if FLAGS.reverse_input:
            ims_rev = ims[:,::-1]
            cost += model.train(ims_rev, lr, mask_true)
            cost = cost/2

        if itr % FLAGS.display_interval == 0:
            print('itr: ' + str(itr))
            print('training loss: ' + str(cost))
        #print('itr: ' + str(itr))#elesun cnt for test
        if itr % FLAGS.test_interval == 0:
            print('test...')
            test_input_handle.begin(do_shuffle = False)
            res_path = os.path.join(FLAGS.gen_frm_dir, str(itr))
            os.mkdir(res_path)
            avg_mse = 0
            batch_id = 0
            img_mse,ssim,psnr,fmae,sharp= [],[],[],[],[]
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                img_mse.append(0)
                ssim.append(0)
                psnr.append(0)
                fmae.append(0)
                sharp.append(0)
            mask_true = np.zeros((FLAGS.batch_size,
                                  FLAGS.seq_length-FLAGS.input_length-1,
                                  FLAGS.img_width/FLAGS.patch_size,
                                  FLAGS.img_width/FLAGS.patch_size,
                                  FLAGS.patch_size**2*FLAGS.img_channel))
            while(test_input_handle.no_batch_left() == False):
                batch_id = batch_id + 1
                #print('batch_id', batch_id, 'is predicting')  # elesun
                test_ims = test_input_handle.get_batch()
                test_dat = preprocess.reshape_patch(test_ims, FLAGS.patch_size)
                #print ("test_dat.shape",test_dat.shape)#elesun test
                #print("mask_true.shape", mask_true.shape)  # elesun test
                img_gen = model.test(test_dat, mask_true)

                # concat outputs of different gpus along batch
                img_gen = np.concatenate(img_gen)
                img_gen = preprocess.reshape_patch_back(img_gen, FLAGS.patch_size)
                # MSE per frame
                for i in range(FLAGS.seq_length - FLAGS.input_length):
                    x = test_ims[:,i + FLAGS.input_length,:,:,0]
                    gx = img_gen[:,i,:,:,0]
                    fmae[i] += metrics.batch_mae_frame_float(gx, x)
                    gx = np.maximum(gx, 0)
                    gx = np.minimum(gx, 1)
                    mse = np.square(x - gx).sum()
                    img_mse[i] += mse
                    avg_mse += mse

                    real_frm = np.uint8(x * 255)
                    pred_frm = np.uint8(gx * 255)
                    psnr[i] += metrics.batch_psnr(pred_frm, real_frm)
                    for b in range(FLAGS.batch_size):
                        sharp[i] += np.max(
                            cv2.convertScaleAbs(cv2.Laplacian(pred_frm[b],3)))
                        score, _ = compare_ssim(pred_frm[b],real_frm[b],full=True)
                        ssim[i] += score

                # save prediction examples
                #print ("test_input_handle.total()",test_input_handle.total())#elesun test len(self.indices)=6
                #print ("length of test_input_handle.frames_path_list",len(test_input_handle.frames_path_list))
                #print ("test_input_handle.frames_path_list",test_input_handle.frames_path_list)
                seq_id = 0
                while (seq_id < FLAGS.batch_size): #elesun test_input_handle.total() len(self.indices)=6
                    seq_id = seq_id + 1
                    #print('seq_id', seq_id, 'is predicting')  # elesun
                    #print("This is batch_id",batch_id,"seq_id",seq_id)
                    #test_input_handle.print_stat()
                    test_frame_path_split = test_input_handle.frames_path_list[
                        ((batch_id-1)*FLAGS.batch_size)*FLAGS.seq_length+((seq_id-1)*FLAGS.seq_length)].split('/')
                    #print ("test_frame_path_split[-1]",test_frame_path_split[-1])
                    # ['..', '..', '..', 'data', 'sfz', 'data_typhoon', 'rgb', 'test_process', 'U_Hour_186.png']
                    #path = os.path.join(res_path, str(batch_id))#elesun test
                    path = os.path.join(res_path, test_frame_path_split[-1])
                    #print("path",path) # results/typhoon_predrnn_pp/62010/U_Hour_186.png
                    os.mkdir(path)
                    for i in range(FLAGS.seq_length):
                        #frames_file_name indices.index ((batch_id * FLAGS.batch_size)*FLAGS.seq_length + i)#elesun test
                        #print ("test_input_handle.frames_path_list",test_input_handle.frames_path_list[0:13])#elesun test
                        #name = 'gt' + "%02d"%(i+1) + '.png'#elesun 'gt' + str(i+1) + '.png'#elesun test
                        #name = "GT_" + (test_input_handle.frames_path_list[(((batch_id-1) * FLAGS.batch_size)*FLAGS.seq_length)+i].split('/'))[3]#elesun test RAD_206482464212530_000.png
                        name = 'gt' + "%02d"%(i+1) + '.png' # elesun test
                        #print("save name",name)
                        file_name = os.path.join(path, name)
                        img_gt = np.uint8(test_ims[0,i,:,:,:] * 255)
                        cv2.imwrite(file_name, img_gt)
                    for i in range(FLAGS.seq_length-FLAGS.input_length):
                        #name = 'pd' + "%02d"%(i+1+FLAGS.input_length) + '.png'#elesun 'pd' + str(i+1+FLAGS.input_length) + '.png'
                        #name = "PD_" + (test_input_handle.frames_path_list[(((batch_id-1) * FLAGS.batch_size)*FLAGS.seq_length) + (i+FLAGS.input_length)].split('/'))[3]  # elesun test RAD_206482464212530_000.png
                        name = 'pd' + "%02d"%(i+1+FLAGS.input_length) + '.png'#elesun 'pd'
                        #print("save name", name)
                        file_name = os.path.join(path, name)
                        img_pd = img_gen[0,i,:,:,:]
                        img_pd = np.maximum(img_pd, 0)
                        img_pd = np.minimum(img_pd, 1)
                        img_pd = np.uint8(img_pd * 255)
                        cv2.imwrite(file_name, img_pd)
                test_input_handle.next()
            avg_mse = avg_mse / (batch_id*FLAGS.batch_size)
            print('mse per seq: ' + str(avg_mse))
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                print(img_mse[i] / (batch_id*FLAGS.batch_size))
            psnr = np.asarray(psnr, dtype=np.float32)/batch_id
            fmae = np.asarray(fmae, dtype=np.float32)/batch_id
            ssim = np.asarray(ssim, dtype=np.float32)/(FLAGS.batch_size*batch_id)
            sharp = np.asarray(sharp, dtype=np.float32)/(FLAGS.batch_size*batch_id)
            print('psnr per frame: ' + str(np.mean(psnr)))
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                print(psnr[i])
            print('fmae per frame: ' + str(np.mean(fmae)))
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                print(fmae[i])
            print('ssim per frame: ' + str(np.mean(ssim)))
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                print(ssim[i])
            print('sharpness per frame: ' + str(np.mean(sharp)))
            for i in range(FLAGS.seq_length - FLAGS.input_length):
                print(sharp[i])
            if avg_mse < metric_value : # model elesun 指标有所提升才进行保存模型
                metric_value = avg_mse
                model.save(itr,avg_mse) # model elesun

        train_input_handle.next()

if __name__ == '__main__':
    tf.app.run()

